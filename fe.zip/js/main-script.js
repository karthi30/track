$( document ).ready(function() {
    $.getJSON( "https://zoomcar-ui.0x10.info/api/courier?type=json&query=list_parcel", function( data ) {
        $('#parcels-count').append(data.parcels.length);
        //alert(JSON.stringify(data.parcels[0]['name']));
        //alert(JSON.stringify(data.parcels.length));
        for (var i=0;i<data.parcels.length;i++){
         $('#dropdown').append('<option class="name">'+data.parcels[i]["name"]+'</option>');
         }
        
        for (var i=0;i<data.parcels.length;i++){
         $('#dropdown').append('<option class="name">'+data.parcels[i]["name"]+'</option>');
         }
        
        
    });
    
});